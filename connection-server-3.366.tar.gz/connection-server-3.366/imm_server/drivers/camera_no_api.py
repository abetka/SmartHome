#!/usr/bin/python

# camera_no_api

mjpg="unknown"
stream="rtsp://@USER@:@DPASSWORD@@@IP@:@RTSP_PORT@@PATH@"

user="@USER@"
password="@EPASSWORD@"
passkey="@PASSKEY@"

def move(where):
    pass

def left():
    move("left")

def right():
    move("right")

def up():
    move("up")

def down():
    move("down")

def zoomIn():
    pass

def zoomOut():
    pass
