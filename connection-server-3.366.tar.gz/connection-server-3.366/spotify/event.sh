#!/bin/bash

python /opt/spotify/event.py "$PLAYER_EVENT" &
