#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'Michal Mrnuštík'
__email__ = 'mmrnustik@gmail.com'
__version__ = '0.1.0'